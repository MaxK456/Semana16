
package examen;

// Clase Paciente basada en tus primeras fotos
class Paciente {
    int id;
    String nombre;
    String enfermedad;

    public Paciente(int id, String nombre, String enfermedad) {
        this.id = id;
        this.nombre = nombre;
        this.enfermedad = enfermedad;
    }

    @Override
    public String toString() {
        return "ID: " + id +
               " | Nombre: " + nombre +
               " | Enfermedad: " + enfermedad;
    }
}
