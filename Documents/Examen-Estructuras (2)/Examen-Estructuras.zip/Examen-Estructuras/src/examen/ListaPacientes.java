
package examen;
class ListaPacientes {
    Nodo primero = null;
    Nodo ultimo = null;
    Nodo actual = null;
    
    static int contadorID = 1;

    // --- AGREGAR PACIENTE ---
    public void agregarPaciente(String nombre, String enfermedad) {
        Paciente p = new Paciente(contadorID++, nombre, enfermedad);
        Nodo nuevo = new Nodo(p);

        if (primero == null) {
            primero = nuevo;
            ultimo = nuevo;
            primero.siguiente = primero;
            primero.anterior = primero;
            actual = primero;
        } else {
            ultimo.siguiente = nuevo;
            nuevo.anterior = ultimo;
            nuevo.siguiente = primero;
            primero.anterior = nuevo;
            ultimo = nuevo;
        }
        System.out.println("Paciente agregado con éxito.");
    }

    // --- BUSCAR PACIENTE ---
    public void buscarPaciente(int idBuscar) {
        if (primero == null) {
            System.out.println("Lista vacía.");
            return;
        }
        Nodo aux = primero;
        boolean encontrado = false;
        do {
            if (aux.paciente.id == idBuscar) {
                System.out.println("Paciente encontrado -> " + aux.paciente);
                encontrado = true;
                break;
            }
            aux = aux.siguiente;
        } while (aux != primero);

        if (!encontrado) {
            System.out.println("Paciente con ID " + idBuscar + " no encontrado.");
        }
    }

    // --- MOSTRAR TODOS LOS PACIENTES ---
    public void mostrarPacientes() {
        if (primero == null) {
            System.out.println("Lista vacía.");
            return;
        }
        Nodo aux = primero;
        System.out.println("\n--- LISTA DE PACIENTES ---");
        do {
            System.out.println(aux.paciente);
            aux = aux.siguiente;
        } while (aux != primero);
    }

    // --- NAVEGACIÓN (Siguiente, Anterior, Actual) ---
    public void siguientePaciente() {
        if (primero == null) {
            System.out.println("Lista vacía.");
            return;
        }
        actual = actual.siguiente;
        System.out.println("Paciente actual: " + actual.paciente);
    }

    public void anteriorPaciente() {
        if (primero == null) {
            System.out.println("Lista vacía.");
            return;
        }
        actual = actual.anterior;
        System.out.println("Paciente actual: " + actual.paciente);
    }

    public void actualPaciente() {
        if (primero == null) {
            System.out.println("Lista vacía.");
            return;
        }
        System.out.println("Paciente actual: " + actual.paciente);
    }

    // --- ORDENAR POR NOMBRE (Bubble Sort adaptado a circular) ---
    public void ordenarNombre() {
        if (primero == null) {
            System.out.println("Lista vacía.");
            return;
        }
        Nodo aux1 = primero;
        do {
            Nodo aux2 = aux1.siguiente;
            while (aux2 != primero) {
                if (aux1.paciente.nombre.compareToIgnoreCase(aux2.paciente.nombre) > 0) {
                    Paciente temp = aux1.paciente;
                    aux1.paciente = aux2.paciente;
                    aux2.paciente = temp;
                }
                aux2 = aux2.siguiente;
            }
            aux1 = aux1.siguiente;
        } while (aux1 != primero);
        System.out.println("Pacientes ordenados por nombre.");
    }

    // --- ORDENAR POR ID ---
    public void ordenarID() {
        if (primero == null) {
            System.out.println("Lista vacía.");
            return;
        }
        Nodo aux1 = primero;
        do {
            Nodo aux2 = aux1.siguiente;
            while (aux2 != primero) {
                if (aux1.paciente.id > aux2.paciente.id) {
                    Paciente temp = aux1.paciente;
                    aux1.paciente = aux2.paciente;
                    aux2.paciente = temp;
                }
                aux2 = aux2.siguiente;
            }
            aux1 = aux1.siguiente;
        } while (aux1 != primero);
        System.out.println("Pacientes ordenados por ID.");
    }

    // --- ELIMINAR PACIENTE POR ID ---
    public void eliminarPaciente(int id) {
        if (primero == null) {
            System.out.println("Lista vacía.");
            return;
        }
        Nodo aux = primero;
        do {
            if (aux.paciente.id == id) {
                // Caso 1: Único nodo en la lista
                if (primero == ultimo) {
                    primero = null;
                    ultimo = null;
                    actual = null;
                } 
                // Caso 2: Es el primer nodo
                else if (aux == primero) {
                    primero = primero.siguiente;
                    primero.anterior = ultimo;
                    ultimo.siguiente = primero;
                    if (actual == aux) actual = primero;
                } 
                // Caso 3: Es el último nodo
                else if (aux == ultimo) {
                    ultimo = ultimo.anterior;
                    ultimo.siguiente = primero;
                    primero.anterior = ultimo;
                    if (actual == aux) actual = primero;
                } 
                // Caso 4: Nodo intermedio
                else {
                    aux.anterior.siguiente = aux.siguiente;
                    aux.siguiente.anterior = aux.anterior;
                    if (actual == aux) actual = primero;
                }
                System.out.println("Paciente eliminado.");
                return;
            }
            aux = aux.siguiente;
        } while (aux != primero);

        System.out.println("No encontrado.");
    }
}