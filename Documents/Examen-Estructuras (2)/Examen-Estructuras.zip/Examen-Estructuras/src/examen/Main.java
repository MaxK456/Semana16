
package examen;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ListaPacientes lista = new ListaPacientes();
        try (Scanner sc = new Scanner(System.in)) {
            int opcion;
            
            do {
                System.out.println("\n===== MENÚ DE GESTIÓN DE PACIENTES =====");
                System.out.println("1. Agregar paciente");
                System.out.println("2. Eliminar paciente por ID");
                System.out.println("3. Buscar paciente por ID");
                System.out.println("4. Mostrar todos los pacientes");
                System.out.println("5. Ordenar pacientes");
                System.out.println("6. Mostrar paciente SIGUIENTE");
                System.out.println("7. Mostrar paciente ANTERIOR");
                System.out.println("8. Mostrar paciente ACTUAL");
                System.out.println("9. Salir del programa");
                System.out.print("Ingrese una opción válida: ");
                opcion = sc.nextInt();
                sc.nextLine(); // Limpiar el buffer
                
                switch (opcion) {
                    case 1 -> {
                        System.out.print("Nombre del paciente: ");
                        String nombre = sc.nextLine();
                        System.out.print("Enfermedad: ");
                        String enfermedad = sc.nextLine();
                        lista.agregarPaciente(nombre, enfermedad);
                    }
                    
                    case 2 -> {
                        System.out.print("ID a eliminar: ");
                        int idEliminar = sc.nextInt();
                        lista.eliminarPaciente(idEliminar);
                    }
                    
                    case 3 -> {
                        System.out.print("ID a buscar: ");
                        int idBuscar = sc.nextInt();
                        lista.buscarPaciente(idBuscar);
                    }
                    
                    case 4 -> lista.mostrarPacientes();
                    
                    case 5 -> {
                        System.out.println("\n--- ORDENAR PACIENTES ---");
                        System.out.println("1. Ordenar por Nombre");
                        System.out.println("2. Ordenar por ID");
                        System.out.print("Seleccione tipo de orden: ");
                        int tipoOrden = sc.nextInt();
                    switch (tipoOrden) {
                        case 1 -> lista.ordenarNombre();
                        case 2 -> lista.ordenarID(); // Nota: Llama a ordenarID() corregido de tu apunte
                        default -> System.out.println("Opción no válida.");
                    }
                    }
                    
                    case 6 -> lista.siguientePaciente();
                    
                    case 7 -> lista.anteriorPaciente();
                    
                    case 8 -> lista.actualPaciente();
                    
                    case 9 -> System.out.println("Saliendo del programa...");
                    
                    default -> System.out.println("Ingrese opción válida.");
                }
            } while (opcion != 9);
        }
    }
}
