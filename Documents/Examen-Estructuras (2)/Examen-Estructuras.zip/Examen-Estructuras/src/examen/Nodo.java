/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen;

/**
 *
 * @author User
 */
public class Nodo {
     Paciente paciente;
    Nodo siguiente;
    Nodo anterior;

    public Nodo(Paciente paciente) {
        this.paciente = paciente;
        this.siguiente = null;
        this.anterior = null;
    }
}
