
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        ListaPacientes lista = new ListaPacientes();

        try (Scanner sc = new Scanner(System.in)) {

            int opcion;

            do {

                System.out.println("\n===== MENÚ DE GESTIÓN DE PACIENTES =====");
                System.out.println("1. Agregar paciente");
                System.out.println("2. Eliminar paciente por ID");
                System.out.println("3. Buscar paciente por ID");
                System.out.println("4. Mostrar todos los pacientes");
                System.out.println("5. Ordenar pacientes");
                System.out.println("6. Mostrar paciente SIGUIENTE");
                System.out.println("7. Mostrar paciente ANTERIOR");
                System.out.println("8. Mostrar paciente ACTUAL");
                System.out.println("9. Salir");

                System.out.print("Ingrese opción: ");
                opcion = sc.nextInt();
                sc.nextLine();

                switch (opcion) {

                    case 1 -> {
                        System.out.print("Nombre: ");
                        String nombre = sc.nextLine();

                        System.out.print("Enfermedad: ");
                        String enfermedad = sc.nextLine();

                        lista.agregarPaciente(nombre, enfermedad);
                    }

                    case 2 -> {
                        System.out.print("ID a eliminar: ");
                        int id = sc.nextInt();

                        lista.eliminarPaciente(id);
                    }

                    case 3 -> {
                        System.out.print("ID a buscar: ");
                        int id = sc.nextInt();

                        lista.buscarPaciente(id);
                    }

                    case 4 -> lista.mostrarPacientes();

                    case 5 -> {
                        System.out.println("1. Ordenar por Nombre");
                        System.out.println("2. Ordenar por ID");

                        int tipo = sc.nextInt();

                        switch (tipo) {
                            case 1 -> lista.ordenarNombre();
                            case 2 -> lista.ordenarID();
                        }
                    }

                    case 6 -> lista.siguientePaciente();

                    case 7 -> lista.anteriorPaciente();

                    case 8 -> lista.actualPaciente();

                    case 9 -> System.out.println("Saliendo...");

                    default -> System.out.println("Opción inválida");
                }

            } while (opcion != 9);
        }
    }
}

/* =========================
   CLASE PACIENTE
   ========================= */

class Paciente {

    int id;
    String nombre;
    String enfermedad;

    public Paciente(int id, String nombre, String enfermedad) {
        this.id = id;
        this.nombre = nombre;
        this.enfermedad = enfermedad;
    }

    @Override
    public String toString() {
        return "ID: " + id +
               " | Nombre: " + nombre +
               " | Enfermedad: " + enfermedad;
    }
}

/* =========================
   CLASE NODO
   ========================= */

class Nodo {

    Paciente paciente;
    Nodo siguiente;
    Nodo anterior;

    public Nodo(Paciente paciente) {
        this.paciente = paciente;
    }
}

/* =========================
   CLASE LISTA PACIENTES
   ========================= */

class ListaPacientes {

    Nodo primero = null;
    Nodo ultimo = null;
    Nodo actual = null;

    static int contadorID = 1;

    // AGREGAR
    public void agregarPaciente(String nombre, String enfermedad) {

        Paciente p = new Paciente(contadorID++, nombre, enfermedad);

        Nodo nuevo = new Nodo(p);

        if (primero == null) {

            primero = nuevo;
            ultimo = nuevo;

            primero.siguiente = primero;
            primero.anterior = primero;

            actual = primero;

        } else {

            ultimo.siguiente = nuevo;
            nuevo.anterior = ultimo;

            nuevo.siguiente = primero;
            primero.anterior = nuevo;

            ultimo = nuevo;
        }

        System.out.println("Paciente agregado.");
    }

    // MOSTRAR
    public void mostrarPacientes() {

        if (primero == null) {
            System.out.println("Lista vacía.");
            return;
        }

        Nodo aux = primero;

        do {

            System.out.println(aux.paciente);

            aux = aux.siguiente;

        } while (aux != primero);
    }

    // BUSCAR
    public void buscarPaciente(int idBuscar) {

        if (primero == null) {
            System.out.println("Lista vacía.");
            return;
        }

        Nodo aux = primero;

        do {

            if (aux.paciente.id == idBuscar) {

                System.out.println("Encontrado:");
                System.out.println(aux.paciente);

                return;
            }

            aux = aux.siguiente;

        } while (aux != primero);

        System.out.println("Paciente no encontrado.");
    }

    // ELIMINAR
    public void eliminarPaciente(int id) {

        if (primero == null) {
            System.out.println("Lista vacía.");
            return;
        }

        Nodo aux = primero;

        do {

            if (aux.paciente.id == id) {

                // SOLO UN NODO
                if (primero == ultimo) {

                    primero = null;
                    ultimo = null;
                    actual = null;
                }

                // PRIMERO
                else if (aux == primero) {

                    primero = primero.siguiente;

                    primero.anterior = ultimo;
                    ultimo.siguiente = primero;
                }

                // ÚLTIMO
                else if (aux == ultimo) {

                    ultimo = ultimo.anterior;

                    ultimo.siguiente = primero;
                    primero.anterior = ultimo;
                }

                // INTERMEDIO
                else {

                    aux.anterior.siguiente = aux.siguiente;
                    aux.siguiente.anterior = aux.anterior;
                }

                System.out.println("Paciente eliminado.");
                return;
            }

            aux = aux.siguiente;

        } while (aux != primero);

        System.out.println("No encontrado.");
    }

    // ACTUAL
    public void actualPaciente() {

        if (actual == null) {
            System.out.println("Lista vacía.");
            return;
        }

        System.out.println(actual.paciente);
    }

    // SIGUIENTE
    public void siguientePaciente() {

        if (actual == null) {
            System.out.println("Lista vacía.");
            return;
        }

        actual = actual.siguiente;

        System.out.println(actual.paciente);
    }

    // ANTERIOR
    public void anteriorPaciente() {

        if (actual == null) {
            System.out.println("Lista vacía.");
            return;
        }

        actual = actual.anterior;

        System.out.println(actual.paciente);
    }

    // ORDENAR NOMBRE
    public void ordenarNombre() {

        if (primero == null) {
            return;
        }

        Nodo aux1 = primero;

        do {

            Nodo aux2 = aux1.siguiente;

            while (aux2 != primero) {

                if (aux1.paciente.nombre.compareToIgnoreCase(aux2.paciente.nombre) > 0) {

                    Paciente temp = aux1.paciente;
                    aux1.paciente = aux2.paciente;
                    aux2.paciente = temp;
                }

                aux2 = aux2.siguiente;
            }

            aux1 = aux1.siguiente;

        } while (aux1 != primero);

        System.out.println("Ordenado por nombre.");
    }

    // ORDENAR ID
    public void ordenarID() {

        if (primero == null) {
            return;
        }

        Nodo aux1 = primero;

        do {

            Nodo aux2 = aux1.siguiente;

            while (aux2 != primero) {

                if (aux1.paciente.id > aux2.paciente.id) {

                    Paciente temp = aux1.paciente;
                    aux1.paciente = aux2.paciente;
                    aux2.paciente = temp;
                }

                aux2 = aux2.siguiente;
            }

            aux1 = aux1.siguiente;

        } while (aux1 != primero);

        System.out.println("Ordenado por ID.");
    }
}
